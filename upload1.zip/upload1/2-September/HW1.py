#def fromkeys solution
def from_keys(d1, value=None):
    #Verify d1 is dictionary
    #verify if value list in container
    result={}
    if type(value)==list or type(value)==tuple:
        lenght=len(d1.keys())
        print (lenght)
        for key in d1.keys():
            if i+1==lenght and i+1<len(value):
                result[key]=value[i:]
            else:
                if i<len(value):
                    result[key]=values[i]
                    i+=1
                else:
                    result[key]=None
    return result

if __name__=='__main__':
    d1=eval(input("Enter dictionary"))
    d2=from_keys(d1)
    print (d2)
