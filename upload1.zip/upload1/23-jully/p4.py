n=eval(input("Enter no"))
summ=0
for x in range (n+1, 2,-2):
    summ+=x
    print ("sum is %d"%summ)
print ("Sum of 1st %d even no is %d"%(n,summ))
