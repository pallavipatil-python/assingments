#write a program to lower and upper bound from user and find out sum of even and odd no saperatly.
l,u=eval(input("Enter lower and upper bound"))
even=0
odd=0
for i in range(l,u):
    if i % 2 == 0:
        even+=i
    else:
        odd+=i
print ("Sum of even no is %d and Sum of odd no is %d" %(even,odd))

