#Write a program to calculate rating where 5 is Exceptional, 4 is Excellent, 3 is Very good, 2 is good and 1 is Poor.
rating=eval(input("Enter your rating"))
if rating == 5:
    print("You are Exceptional")
elif rating == 4:
    print("You are Excellent")
elif rating == 3:
    print("You are Very Good")
elif rating == 2:
    print("You are Good")
elif rating == 1:
    print("You are Poor")
else:
    print("Enter correct rating")
    
    
    
          
