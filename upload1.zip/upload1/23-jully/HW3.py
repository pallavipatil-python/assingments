#write a program to keep on adding no until user enters zero
n1=eval(input("Enter no"))
summ=0
while n1 != 0:
    n1=eval(input("Enter no"))
    summ +=n1
    print ("Sum is %d" %summ)
