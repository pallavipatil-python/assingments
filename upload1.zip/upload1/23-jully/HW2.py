#Write a program to accept a range from user and display sum of multiples of 6, in given range
s,e=eval(input("Enter range"))
summ=0
for i in range (s,e):
    if i % 6 == 0:
        summ += i
print ("Sum is %d" %summ)
    

