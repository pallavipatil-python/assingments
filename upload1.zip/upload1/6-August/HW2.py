#WaP to accept no from user and display the count and digit which occours maximum no of time.
#112311 and = 1 is 4
