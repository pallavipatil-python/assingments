#WaP to accept a no from user and define a function sum of cubes of digits :
#no=123 ans=1**3 + 2**3 + 3**3 = 27 + 8 + 1= 36 

def DegSeparate(no):
    s=0
    while no != 0:
        print (no)
        d=int(no%10)
        c=d*d*d
        s=s + c
        print(s)
        no=int(no/10)
    return s

if __name__ == '__main__':
    no=eval(input("Enter no:"))
    s=DegSeparate(no)
    print("Cube is",s)
