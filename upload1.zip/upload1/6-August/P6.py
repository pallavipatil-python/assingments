#WaP to print pattern
# * * * *
# * * *
# * *
# *
def parrern(n):
    for i in range(n,0):
        for j in range(n,i):
            print('*\t',end='')
        print("\n")

if __name__ == '__main__':
    pattern(n)
    

