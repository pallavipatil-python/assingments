#WaP to print pattern
# * * * * *
#   * * * *
#     * * *
#       * *
#         *


def pattern(n):
    #print (n)
    for j in range(0,n):
        #print ("j",j,end='')
        for k in range (0,j):
          #  print ("k",k,end='')
            print('\t',end='')
        for l in range (n-j,0,-1):
           # print ("l",l,end='')
            print('*\t',end='')
        print('\n')

if __name__== '__main__':
    n=eval(input("Enter no:"))
    pattern(n)
