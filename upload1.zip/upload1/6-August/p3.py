#WaP to accept no from user and check where is no Pelindrom
def pelindrom(no):
    n=0
    rem=0
    x=no
    while no != 0:
        rem=int(no)%10
        no=int(no/10)
        n=int(n*10) + rem
        #print("rem:",rem)
        #print("n:",n)
        #print("no:",no)
    return n
def pelindrom(n,x):
    r=rev(n)
    print("Reveser is :%d"%n)
    if n == r:
        print("No is pelindrom")
    else:
        print("No is not pelindrom")

if __name__ == '__main__':
    n=eval(input("Enter no:"))
    pelindrom(n)
    
