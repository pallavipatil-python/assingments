#WaP accept 2 no from user and find GCD of them.
#!/usr/bin/python
def gcd(n1,n2):
    while n1 != n2:
        print (n1,n2)
        if n1 > n2:
            n1=n1-n2
            print("n1:",n1)
        else:
            n2=n2-n1
            print("n2:",n2)
    return n1

def main():
    n1,n2=eval(input("Enter 2 no:"))
    op=gcd(n1,n2)
    print("GCD is:",op)

if __name__=='__main__':
    main()
