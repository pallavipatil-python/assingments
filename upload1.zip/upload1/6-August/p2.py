#WaP to accept no from user and print its revrse
def rev(no):
    n=0
    rem=0
    while no != 0:
        rem=int(no)%10
        no=int(no/10)
        n=int(n*10) + rem
        print("rem:",rem)
        print("n:",n)
        print("no:",no)
    return n
if __name__ == '__main__':
    n=eval(input("Enter no:"))
    op=rev(n)
    print("Reverse is :",op)
