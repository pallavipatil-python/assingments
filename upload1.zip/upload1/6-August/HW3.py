#WaP to accept a no from user and check if it is armstrong no
#sum of cubes of digit is original no(eg:153)
def DegSeparate(no):
    s=0
    while no != 0:
        print (no)
        d=int(no%10)
        c=d*d*d
        s=s + c
        print(s)
        no=int(no/10)
    return s

if __name__ == '__main__':
    no=eval(input("Enter no:"))
    s=DegSeparate(no)
    print("Cube is",s)
    if no == s:
        print("Armstrong no")
    else:
        print("Not Armstrong no")
