#WaP to print pattern
#      *
#   *  *  *
#*  *  *  *  *
#   *  *  *
#      *


def pattern(n):
    #print (n)
    for j in range(0,n):
        #print ("j",j,end='')
        for k in range (n-j,0,-1):
          #  print ("k",k,end='')
            print('\t',end='')
        for l in range (0,j-k+1):
           # print ("l",l,end='')
            print('*\t\t',end='')
        print('\n')
    for m in range(0,n):
        #print(m,end='')
        for q in range(0,m):
            print('\t',end='')
        for p in range(n-m,0,-1):
            print('*\t\t',end='')
        print('\n')
if __name__== '__main__':
    n=eval(input("Enter no:"))
    pattern(n)
