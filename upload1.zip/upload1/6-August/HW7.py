#WaP to print pattern
#*  *  *  *  *
#   *  *  *
#      *

def pattern(n):
    #print (n)
     for m in range(0,n):
        #print(m,end='')
        for q in range(0,m):
            print('\t',end='')
        for p in range(n-m,0,-1): #range (0,2*(n-i)+1)
            print('*\t\t',end='')
        print('\n')
if __name__== '__main__':
    n=eval(input("Enter no:"))
    pattern(n)
