#!/usr/bin/python
print("Its fun", __name__)
def sumofevenodd(lb,ub):
    sum1=0
    sum2=0
    print (lb,ub)
    while lb<=ub:
        #print (lb,ub)
        if lb % 2==0:
            sum1+=lb
            #print("sum1:",sum1)
        else:
            sum2+=lb
            #print("sum2:",sum2)
            #print("lb",lb)
        lb+=1
    #print(sum1,sum2)
    return sum1,sum2
if __name__=='__main__':
     lb,ub=eval(input("Enter range"))
     r1,r2=sumofevenodd(lb,ub)
     print("Sum of even is :",r1)
     print("Sum of odd is :",r2)
        
