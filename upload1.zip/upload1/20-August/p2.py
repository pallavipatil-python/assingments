#WaP to accept alpha numeric string and display sum of all nos:

def sumofdigits(s):
    i=0
    add=0
    while len(s) != i:
        if s[i].isdigit():
            add=add + int(s[i])
            #print(add)
        i+=1
    return add

if __name__== '__main__':
    s=eval(input("Enter alphanumeric string:"))
    sum1=sumofdigits(s)
    print("Sum of digits is ",sum1)
