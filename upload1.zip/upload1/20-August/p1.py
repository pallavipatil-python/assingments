#WaP to accept 2 strings from user and check if 2nd string is rotation of 1st.
#pallavi , rotation strings are, allavip

def rotation(x,y):
    if len(x) != len(y):
        return False 
    return y in x+x 

if __name__ == '__main__':
    x,y=eval(input("Enter 2 strings"))
    s=rotation(x,y)
    print(s)
    if s == True:
        print("{} is rotation of {}" .format(y,x))
    else:
        printprint("{} is not rotation of {}" .format(y,x))


    
