#WaP to accept a string from user which has comsicative repitative charactors,
#the op should be the string where count of no
#aaabbbcccdabe == op =a3b3c3dabe
def str_count(s):
    i=0
    new_s=''
    while len(s)!= i:
        n=s.count(s[i])
        if n > 1:
            new_s=s[i] + n
            print(new_s)
        else:
            new_s=s[i]

        i+=1
    return new_s

if __name__ =='__main__':
    s=eval(input("Enter string"))
    print (s)
