#WaP to accept 2 strings from user and count accource of search string in main string without using count method
'''
def search(s1,s2):
    count=0
    i=0
    while i < len(s1):
        if s1[i] == s2:
            count+=1
        i+=1
        #print (count) 
    return count
'''
def search(s1,s2):
    count=0
    op=0
    while op != -1:
        op=s1.find(s2)
        if op != -1:
            count+=1
            #print(count)
        #else:
        s1=s1[op+1:]
        #print(s1)
            

if __name__=='__main__':
    s1,s2=eval(input("Enter main string and search string:"))
    a=search(s1,s2)
    print(a)
