#WaP to implement queue using list
