#WaP to accept string from user and replacement charachor from user , replace all accornce
#ip=babble
#*
#op=ba**le

def replace_char(x,r):
    print("hi")
    return x[0] + x[1:].replace(x[0],r)

if __name__ == '__main___':
    print("AAA")
    x,r=eval(input("Enter string and replace by char:"))
    y=replace_char(x,r)
    print(y)

'''
op=ip[0]
ch=ip[0]
i=1
while i < len(ip):
    if ip[i]==ch:
        op=replaceby
        
    else
        op+=ip[i]
    i+=1
'''
