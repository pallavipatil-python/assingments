#WaP to accept stm form user and replace accournce of 'not xxx bad' with good(change bad word with good) 
def replace(x):





if __name__=='__main__':
    x=eval(input("Enter stm:"))
    replace(x)
