def sum1():
    summ=0
    for i in range (1,101):
        if i % 5 == 0 :
            continue
        summ+=i
    print("Sum is %d"%summ)
sum1()
