
def sum1(n):
    summ=0
    for x in range (2, n+1,2):
        summ+=x
    print ("Sum of 1st %d even no is %d"%(n,summ))
n=eval(input("Enter no:"))
sum1(n)
