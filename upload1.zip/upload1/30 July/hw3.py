#Calculate %
def percent(a,b,c):
        return ((n1+n2+n3)/3)

def percentall(*args):
    summ=0
    no=0
    for i in args:
        summ=summ+i
        no=no+1
        per=summ/no
    return per

n1,n2,n3=eval(input("Enter marks of 3 nos:"))
percent1=percent(n1,n2,n3)
print("Percentages are :",percent1)
percent2=percentall(50,60,50,60,50,60)
print("percentall function:",percent2)
