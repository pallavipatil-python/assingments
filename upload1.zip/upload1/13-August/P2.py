#WaP to merge 2 sorted lists
def mergelist(a,b):
    a.sort()
    b.sort()


if __name__=='__main__':
    l1=eval(input("Enter List1:"))
    l2=eval(input("Enter List2:"))
    mergelist(l1,l2)


