#WaP to compare 2 lists
def comparelists(a,b):
    a.sort()
    b.sort()
    for val1 in range(0,len(a)):
        temp1=a[val1]
        temp2=b[val1]
        for val2 in range(0,len(b)):
            if(temp1[val2]==temp2[val2]):
                print("Same")
    return True
if __name__=='__main__':
    l1=eval(input("Enter list 1:"))
    l2=eval(input("Enter list 2:"))
    op=comparelists(l1,l2)
    print(op)
    if op == True :
        print("Lists are same")
    else:
        print ("Lists are not same")
