#WaP to do union of lists
def union(l1,l2):
    l3=l1
    i=0
    while i < len(l2):
        if l2[i] not in l3:
            l3.append(l2[i])
        i+=1
    return l3

if __name__ == '__main__':
    l1=eval(input("Enter l1:"))
    l2=eval(input("Enter l2:"))
    l3=union(l1,l2)
    print(l3)
