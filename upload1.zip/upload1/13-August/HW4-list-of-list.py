#WaP conver list of list to 1 list
def nutralise_list(l1):
    i=0
    l2=[]
    while i < len(l1):
        if type(l1[i]) != list :
            l2.append(l1[i])
        else:
            extend_list(l2,l1[i])
        i+=1
       # print (l2)
    return l2
def extend_list(l2,l3):
    j=0
    while j < len(l3):
        if type(l3[j]) != list:
            l2.append(l3[j])
        else:
            extend_list(l2,l3[j])
        j+=1
        #print (l2)



if __name__ == '__main__':
    l1=eval(input("Enter l1:"))
    l3=nutralise_list(l1)
    print(l3)
