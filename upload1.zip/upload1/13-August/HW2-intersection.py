#WaP for intersection of 2 lists

#not working
[1,2,3] , [2,3,4]
op 2,3
def intersection(l1,l2):
    l3=l1
    i=0
    while i < len(l2):
        if l2[i] in l1:
            l3.append(l2[i])
        i+=1
    return l3

if __name__ == '__main__':
    l1=eval(input("Enter l1:"))
    l2=eval(input("Enter l2:"))
    l3=intersection(l1,l2)
    print(l3)
