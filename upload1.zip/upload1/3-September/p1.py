#WaP to accept 2 disctionaries and compare them vaules vise, resutrn true if they are same else false
def comp(d1,d2):
    result= True
    if len(d1.keys()) == len(d1.keys()):
        for keys in d1.keys():
            if keys in d2.keys() and d1[keys]==d2[keys]:
                continue
            result =False
            break
    return result
if __name__=='__main__':
    d1=eval(input("Enter 1st dictionary:"))
    d2=eval(input("Enter d2nd dictionary:"))
    res=comp(d1,d2)
    if res ==True:
        print ("Both dictonaries are same")
    else:
        print ("Both dictonaries are NOT same")
