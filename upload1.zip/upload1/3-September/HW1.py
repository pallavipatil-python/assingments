#WaP for file handeling
#Open file with name=pallavi, surname=patil and add in dictonary
'''>>> fd=open("test.txt")
>>> lines=fd.readlines()
>>> print (lines)
['Hello world']
>>> lines
['Hello world']'''
def file1(l):
    print(l)
    s=str(l)#Converting list to string as split fun not present for list
    t=s.split('\n')#spliting by lines
    print(t)
    d={}
    a=s.split(':')
    print(a)


if __name__=='__main__':
    fd=open("test.txt")
    #x=file1(C:\Python34\practice\3-September\test.txt)
    lines=fd.readlines()
    x=file1(lines)
    print(x)
