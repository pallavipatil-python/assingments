#List
L1=[1,2,3]
i=0
while i < len(L1):
    print (L1[i])
    i+=1


L1.append([5,6,7])
print(L1)
L1.extend([8,9,10])
print(L1)
L1.insert(2,10)
print(L1)
L1.insert(50,11)
print(L1)
L1.pop()
print(L1)
L1.pop(2)
print(L1)
L1.remove([5,6,7])
print(L1)

