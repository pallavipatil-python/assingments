#WaP to accept a list from user and an element whoes presence/accource in list is counted
l1=eval(input("Enter list"))
n=eval(input("Enter no"))
count=0
for i in l1:
    if i == n:
        count=count+1
        print(count)
print(count)
