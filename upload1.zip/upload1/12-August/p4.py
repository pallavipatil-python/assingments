#WaP to reverse list
l1=eval(input("Enter List:"))
print("l1",l1)
l2=[]
len1=len(l1)
for i in range(len1,0,-1):
    l2.append(i)
print("l2",l2)
    
