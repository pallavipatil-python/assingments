#WaP to implement a stack using list
