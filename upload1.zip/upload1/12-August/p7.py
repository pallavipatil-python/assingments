#WaP to accept list of integers from user and display max n min out of them
def minmax(l1):
    min1=l1[0]
    max1=l1[0]
    for i in l1:
        if i > max1:
            max1=i
        if i < min1:
            min1=i
    return max1,min1

if __name__=='__main__':
    l1=eval(input("Enter list"))
    max1,min1=minmax(l1)
    print("Max",max1)
    print("Min",min1)
        
    
