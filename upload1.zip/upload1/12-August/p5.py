#
x=list("Pallavi")
print(x)
l1=[1,2,3]
l2=[4,5,6]
print(l1 + l2)
print(l1.index(3))
