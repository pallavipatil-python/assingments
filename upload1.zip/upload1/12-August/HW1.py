#WaP to accept no from user and print pattern like
#              A
#        B     A    B
#    C   B     A    B    C
