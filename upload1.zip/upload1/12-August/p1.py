#WaP to print pattern
#A
#A  B
#A  B  C
#A  B  C  D
def pattern(n):
    for i in range (0,n):
            ch=65
            for j in range (0,i+1):
                print('%c\t' %ch,end='')
                ch=ch + 1
            print('\n')
if __name__ == '__main__':
    n=eval(input("Enter No: "))
    pattern(n)
