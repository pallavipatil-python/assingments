#WaP to compair 2 lists elements wise
(sort,l1[0]and l2[0])
