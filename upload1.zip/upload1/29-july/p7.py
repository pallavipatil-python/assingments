#Function kayword arguments
def add(a,b):
    print("A=%d and B=%d" %(a,b))
    return a+b

res=add(b=10,a=20)
print ("Result is %d" %res)
    
