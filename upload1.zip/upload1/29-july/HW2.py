#Write function which can add any no of argumnets
#Function: variable no of arguments
def VariableArgsAdd(*args):
    print(type(args))
    sum=0
    for x in args:
        print(x)
        sum +=x
res=VariableArgsAdd(1,2,3)
print(res)
res=VariableArgsAdd(1,2,3,4,5,6,7,8)
print(res)
