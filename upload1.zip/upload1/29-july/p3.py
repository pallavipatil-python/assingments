#Function demo
def demo(a,b):
    return a+b
res=demo(10,20)
print ("Result is %d"%res)
