#Function : default and positional arguments
def demo(a,b=10):
    return a+b

result=demo(10,30)
print ("Result of a+b is : %d" %result)
result=demo(100)
print ("Result of a+b is : %d" %result)
