#While .... else example
x=1
while x != 20:
   # if x % 10 ==0:
   #     break
    print (x)
    x +=1
else:
    print ("In else loop")
