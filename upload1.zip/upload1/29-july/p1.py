#for .... else
for x in range (1,10):
    print (x)
    if x % 7 == 0:
        break
else:
    print ("Else loop executed completely")
    
