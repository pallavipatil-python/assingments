#Write a function which can add 2 or 3 or 4 or 5 no
#Write a function to do multiplication of 3 or 4 or 5 no
def multiplication(a,b,c=1,d=1,e=1):
    return a+b+c+d+e

result=multiplication(2,3)
print("Addition of 2 no is : %d" %result)
result=multiplication(2,3,4)
print("Addition of 3 no is : %d" %result)
result=multiplication(2,3,4,5)
print("Addition of 4 no is : %d" %result)
result=multiplication(2,3,4,5,6)
print("Addition of 5 no is : %d" %result)
result=multiplication(2,3,4,5,6)
print("Addition of 5 no is : %d" %result)
result=multiplication(2,3,4,5,e=1)
print("Addition of 5 no is : %d" %result)
